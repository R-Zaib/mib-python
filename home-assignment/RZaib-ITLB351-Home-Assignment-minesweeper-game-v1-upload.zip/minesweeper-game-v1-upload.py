# minesweeper game home assignment

import random

# asking the user to enter grid size
grid_size = int(input("Enter the board size in square to play: "))

# number of mines to be placed in the grid
num_mines = int(input("Enter the number of mine to be placed in the board: "))


# using the input to create a nested list, which serves as a 2D board.
board_grid = [["#"for i in range(grid_size)] for j in range(grid_size)]

# placing the mines using random
mine_location = random.sample(range(grid_size ** 2), num_mines)

# printing the board to show the game board
print(board_grid)


reveal = input("What field to reveal?")


# work in progress:
# 1- how to reprompt user if it is not a positive integer
# 2- how to show the board in 2D style
# 3- how to present the mines in the mine_location variable 
# 4- use the randon.randit for mine placement
# 5- create game logic and work on functions to make the game playable
